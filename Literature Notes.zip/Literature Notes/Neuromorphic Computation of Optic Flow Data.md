Title: Neuromorphic Computation of Optic Flow Data
Author: Valette, Florent et al.
Topic: #neuromorphiccomputing 
Publication date: 2009
Retrieved date: 05-07-2022 

### Background
- [[ESA]] report on a potential lander mission

### Method
### Results
### Data 
### Conclusions
### Significance
### My Notes
- Not relevant, [[neuromorphic computing]] is only mentioned in the title

